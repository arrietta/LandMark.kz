<!-- нижняя полоса сайта  -->

<style>
    .footer {
        background-color: #f8f9fa;
        padding-top: 20px;
        padding-bottom: 20px;
        bottom:0;
        width: 100%;
       
        
    }
</style>

<footer class="footer mt-auto py-3 bg-light">
  <div class="container text-center">
    <span class="text-muted">
      <a href="about.php">О нас</a> |
      <a href="about.php">instagram</a> | 
      <a href="about.php">Email</a>
    </span>
    <br>
  </div>
</footer>
